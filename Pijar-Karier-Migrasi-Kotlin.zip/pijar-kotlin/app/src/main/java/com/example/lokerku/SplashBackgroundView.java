package com.example.lokerku;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class SplashBackgroundView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();

    private float[] px = new float[70];
    private float[] py = new float[70];
    private float[] speed = new float[70];
    private float[] radius = new float[70];

    private float time = 0f;
    private int viewWidth;
    private int viewHeight;

    public SplashBackgroundView(Context context) {
        super(context);
        init();
    }

    public SplashBackgroundView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SplashBackgroundView(Context context, AttributeSet attrs,
                                int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        for (int i = 0; i < px.length; i++) {
            px[i] = random.nextFloat();
            py[i] = random.nextFloat();
            speed[i] = 0.0003f + random.nextFloat() * 0.0008f;
            radius[i] = 1f + random.nextFloat() * 2.2f;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        viewWidth = w;
        viewHeight = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (viewWidth <= 0 || viewHeight <= 0) {
            return;
        }

        canvas.drawColor(Color.rgb(3, 8, 20));

        drawAmbientGlow(canvas);
        drawPortal(canvas);
        drawRoad(canvas);
        drawParticles(canvas);

        time += 0.018f;

        postInvalidateDelayed(30);
    }

    private void drawAmbientGlow(Canvas canvas) {
        paint.setShader(new RadialGradient(
                viewWidth * 0.53f,
                viewHeight * 0.48f,
                viewWidth * 0.75f,
                new int[]{
                        Color.argb(65, 0, 90, 255),
                        Color.argb(28, 0, 45, 130),
                        Color.TRANSPARENT
                },
                null,
                Shader.TileMode.CLAMP
        ));

        canvas.drawRect(0, 0, viewWidth, viewHeight, paint);
        paint.setShader(null);

        float glowX = viewWidth * (0.5f + 0.08f *
                (float) Math.sin(time * 0.7f));

        paint.setShader(new RadialGradient(
                glowX,
                viewHeight * 0.65f,
                viewWidth * 0.45f,
                new int[]{
                        Color.argb(70, 0, 119, 255),
                        Color.argb(20, 0, 67, 170),
                        Color.TRANSPARENT
                },
                null,
                Shader.TileMode.CLAMP
        ));

        canvas.drawRect(0, 0, viewWidth, viewHeight, paint);
        paint.setShader(null);
    }

    private void drawPortal(Canvas canvas) {
        float centerX = viewWidth * 0.72f;
        float top = viewHeight * 0.48f;
        float bottom = viewHeight * 0.76f;
        float portalWidth = viewWidth * 0.28f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(Color.argb(45, 35, 145, 255));

        Path outer = new Path();
        outer.moveTo(centerX - portalWidth, bottom);
        outer.lineTo(centerX - portalWidth * 0.72f, top + 20);
        outer.quadTo(centerX, top - 20,
                centerX + portalWidth * 0.35f, top + 25);
        outer.lineTo(centerX + portalWidth * 0.7f, bottom);

        paint.setShadowLayer(22f, 0, 0,
                Color.rgb(0, 91, 255));
        canvas.drawPath(outer, paint);
        paint.clearShadowLayer();

        paint.setStyle(Paint.Style.FILL);

        paint.setShader(new RadialGradient(
                centerX,
                (top + bottom) / 2f,
                portalWidth * 1.5f,
                new int[]{
                        Color.argb(48, 0, 132, 255),
                        Color.TRANSPARENT
                },
                null,
                Shader.TileMode.CLAMP
        ));

        canvas.drawRect(
                centerX - portalWidth * 1.5f,
                top,
                centerX + portalWidth * 1.5f,
                bottom,
                paint
        );

        paint.setShader(null);
    }

    private void drawRoad(Canvas canvas) {
        Path road = new Path();

        road.moveTo(-viewWidth * 0.1f, viewHeight * 0.84f);

        road.cubicTo(
                viewWidth * 0.15f, viewHeight * 0.79f,
                viewWidth * 0.95f, viewHeight * 0.80f,
                viewWidth * 0.70f, viewHeight * 0.69f
        );

        road.cubicTo(
                viewWidth * 0.45f, viewHeight * 0.60f,
                viewWidth * 0.35f, viewHeight * 0.56f,
                viewWidth * 0.82f, viewHeight * 0.49f
        );

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f);
        paint.setColor(Color.argb(180, 25, 125, 255));
        paint.setShadowLayer(18f, 0, 0,
                Color.rgb(0, 103, 255));

        canvas.drawPath(road, paint);

        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawParticles(Canvas canvas) {
        for (int i = 0; i < px.length; i++) {
            py[i] -= speed[i];

            if (py[i] < 0f) {
                py[i] = 1f;
                px[i] = random.nextFloat();
            }

            float x = px[i] * viewWidth;
            float y = py[i] * viewHeight;

            float pulse = (float) Math.sin(time + i) * 0.5f;
            float r = Math.max(0.5f, radius[i] + pulse);

            int alpha = 75 + (int) (
                    (Math.sin(time * 1.4f + i) + 1f) * 65f
            );

            paint.setColor(Color.argb(
                    alpha, 60, 160, 255
            ));

            paint.setStyle(Paint.Style.FILL);
            paint.setShadowLayer(8f, 0, 0,
                    Color.rgb(0, 100, 255));

            canvas.drawCircle(x, y, r, paint);

            paint.clearShadowLayer();
        }
    }
}