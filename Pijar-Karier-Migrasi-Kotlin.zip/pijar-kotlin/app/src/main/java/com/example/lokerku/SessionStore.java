package com.example.lokerku;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** The application session token is encrypted with a non-exportable Android Keystore key. */
final class SessionStore {
    private static final String ALIAS = "lokerku_session_v1";
    private static SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            generator.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
    }
    static void save(Context c,String token) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted=cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
        SharedPreferences p=c.getSharedPreferences("lokerku_secure",Context.MODE_PRIVATE);
        if(!p.edit().putString("iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP))
                .putString("token",Base64.encodeToString(encrypted,Base64.NO_WRAP)).commit()) throw new Exception("save failed");
    }
    static String get(Context c) {
        try {
            SharedPreferences p=c.getSharedPreferences("lokerku_secure",Context.MODE_PRIVATE);
            String v=p.getString("token",null), iv=p.getString("iv",null); if(v==null||iv==null) return "";
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(v,Base64.NO_WRAP)),StandardCharsets.UTF_8);
        } catch(Exception e) { return ""; }
    }
    static void clear(Context c) { c.getSharedPreferences("lokerku_secure",Context.MODE_PRIVATE).edit().clear().apply(); }
}
