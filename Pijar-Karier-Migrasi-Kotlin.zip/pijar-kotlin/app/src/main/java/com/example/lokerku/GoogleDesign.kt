package com.example.lokerku

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

object GoogleDesign {
    @JvmStatic fun addTo(parent: LinearLayout, context: Context, title: String) {
        val density = context.resources.displayMetrics.density
        val group = LinearLayout(context).apply {
            gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = 18*density; setStroke(density.roundToInt(),0xff747775.toInt())
            }
        }
        val logo = ImageView(context).apply {
            setImageResource(R.drawable.google_g_official); scaleType = ImageView.ScaleType.FIT_CENTER
        }
        group.addView(logo,LinearLayout.LayoutParams((25*density).roundToInt(),(25*density).roundToInt()))
        val label = TextView(context).apply {
            text = title; textSize = 14f; setTextColor(0xff1f1f1f.toInt()); typeface = AppFont.semibold(context)
        }
        group.addView(label,LinearLayout.LayoutParams(-2,-2).apply { leftMargin = (12*density).roundToInt() })
        group.contentDescription = title
        group.setOnClickListener {
            if (group.isEnabled) {
                group.isEnabled = false; label.text = "Menghubungkan ke Google…"
                GoogleSignInFlow.signIn(context as Activity, context is RegisterActivity) {
                    group.isEnabled = true; label.text = title
                }
            }
        }
        parent.addView(group,LinearLayout.LayoutParams(-1,(52*density).roundToInt()).apply { topMargin = (16*density).roundToInt() })
    }
}
