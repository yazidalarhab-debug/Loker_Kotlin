package com.example.lokerku

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.view.View
import android.view.animation.DecelerateInterpolator

/** A short brand reveal, not an indicator of network progress. */
class LokerKuSplashView(context: Context) : View(context) {
    fun interface AnimationListener { fun onAnimationFinished() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
    private var listener: AnimationListener? = null
    private var animator: ValueAnimator? = null
    private var progress = 1f
    private var started = false
    private var finished = false

    init { contentDescription = "Pijar Karier, langkah kecil peluang besar" }
    fun setAnimationListener(value: AnimationListener) { listener = value }
    private fun dp(n: Float) = n * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, oldW: Int, oldH: Int) {
        super.onSizeChanged(w, h, oldW, oldH)
        if (started || w == 0 || h == 0) return
        started = true
        if (Build.VERSION.SDK_INT >= 26 && !ValueAnimator.areAnimatorsEnabled()) {
            post { finishReveal() }; return
        }
        progress = 0f
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) finishReveal() }
            })
            start()
        }
    }

    private fun finishReveal() {
        if (!finished) { finished = true; listener?.onAnimationFinished() }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat(); val x = w / 2f; val y = h * .43f
        canvas.drawColor(PijarStyle.PURPLE_DARK)
        paint.color = 0x337f5cd0; canvas.drawCircle(w*.08f, h*.17f, w*.33f, paint)
        paint.color = 0x44ff896f; canvas.drawCircle(w*.94f, h*.78f, w*.23f, paint)
        canvas.save(); canvas.translate(x, y + dp(10f)*(1-progress))
        paint.color = PijarStyle.CORAL; canvas.drawRoundRect(-dp(43f),-dp(43f),dp(43f),dp(43f),dp(27f),dp(27f),paint)
        paint.color = 0xfffff7e9.toInt()
        val star = Path().apply {
            moveTo(0f,-dp(27f)); quadTo(dp(5f),-dp(5f),dp(26f),0f)
            quadTo(dp(5f),dp(5f),0f,dp(27f)); quadTo(-dp(5f),dp(5f),-dp(26f),0f)
            quadTo(-dp(5f),-dp(5f),0f,-dp(27f)); close()
        }
        canvas.drawPath(star, paint); canvas.restore()
        paint.textAlign = Paint.Align.CENTER; paint.typeface = AppFont.semibold(context)
        paint.textSize = minOf(dp(30f), w*.078f); paint.color = 0xffffffff.toInt()
        canvas.drawText("Pijar Karier",x,y+dp(91f),paint)
        paint.typeface = AppFont.regular(context); paint.textSize = minOf(dp(13f),w*.034f)
        paint.color = 0xffe9defb.toInt(); canvas.drawText("Langkah kecil, peluang besar.",x,y+dp(121f),paint)
        paint.color = PijarStyle.MINT; canvas.drawCircle(x-dp(10f),h*.83f,dp(3f),paint)
        paint.color = PijarStyle.CORAL; canvas.drawCircle(x,h*.83f,dp(3f),paint)
        paint.color = 0xffffd88a.toInt(); canvas.drawCircle(x+dp(10f),h*.83f,dp(3f),paint)
    }
    fun pauseAnimations() { animator?.let { if (it.isRunning) it.pause() } }
    fun resumeAnimations() { animator?.let { if (it.isPaused) it.resume() } }
    fun stopAnimations() { animator?.cancel(); animator = null }
}
