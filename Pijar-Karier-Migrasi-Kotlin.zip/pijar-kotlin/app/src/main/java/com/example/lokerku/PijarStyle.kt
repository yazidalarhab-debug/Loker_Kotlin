package com.example.lokerku

import android.content.Context
import android.graphics.drawable.GradientDrawable

/** Shared semantic colors and surfaces for Pijar Karier. */
object PijarStyle {
    @JvmField val INK = 0xff282343.toInt()
    @JvmField val MUTED = 0xff69647c.toInt()
    @JvmField val PURPLE = 0xff5935b1.toInt()
    @JvmField val PURPLE_DARK = 0xff3f247e.toInt()
    @JvmField val LAVENDER = 0xffeee8ff.toInt()
    @JvmField val CREAM = 0xfffff9f3.toInt()
    @JvmField val CORAL = 0xffff896f.toInt()
    @JvmField val MINT = 0xffd4f2e6.toInt()

    @JvmStatic fun surface(context: Context, color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * context.resources.displayMetrics.density
        }

    @JvmStatic fun gradient(context: Context, a: Int, b: Int, radius: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply {
            cornerRadius = radius * context.resources.displayMetrics.density
        }
}
