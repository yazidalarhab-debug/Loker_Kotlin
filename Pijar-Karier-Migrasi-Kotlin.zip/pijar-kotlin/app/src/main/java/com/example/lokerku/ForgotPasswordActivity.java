package com.example.lokerku;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ForgotPasswordActivity extends AppCompatActivity {

    private static final String URL_FORGOT_PASSWORD =
            "https://ahannaja.cu.ma/lokerku_api/auth/forgot_password.php";

    private final int NAVY = Color.rgb(21, 26, 61);
    private final int TEAL = Color.rgb(0, 0, 255);
    private final int BG = Color.rgb(247, 248, 255);
    private final int TEXT = Color.rgb(21, 26, 61);
    private final int MUTED = Color.rgb(104, 112, 143);
    private final int WHITE = Color.WHITE;

    private EditText etEmail;
    private Button btnReset;
    private ProgressBar progressBar;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                            | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            );
        }

        requestQueue = Volley.newRequestQueue(
                getApplicationContext()
        );

        tampilkanHalaman();
    }

    private void tampilkanHalaman() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(26), dp(20), dp(26), dp(30));
        root.setGravity(Gravity.CENTER_VERTICAL);

        scrollView.addView(root);
        setContentView(scrollView);
        FontEnforcer.apply(scrollView, this);

        TextView back = new TextView(this);
        back.setText("‹  Kembali ke Login");
        back.setTextSize(15);
        back.setTextColor(TEAL);
        back.setTypeface(AppFont.semibold(this));
        back.setPadding(0, dp(8), 0, dp(24));
        back.setOnClickListener(v -> finish());
        root.addView(back);

        LinearLayout logo = new LinearLayout(this);
        logo.setGravity(Gravity.CENTER);
        logo.setOrientation(LinearLayout.HORIZONTAL);
        logo.setPadding(dp(20), dp(18), dp(20), dp(18));
        GradientDrawable brandBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(0, 0, 204), Color.rgb(51, 51, 255)});
        brandBg.setCornerRadius(dp(24));
        logo.setBackground(brandBg);

        TextView logoIcon = new TextView(this);
        logoIcon.setText("L");
        logoIcon.setTextColor(WHITE);
        logoIcon.setTextSize(28);
        logoIcon.setTypeface(AppFont.semibold(this));
        logoIcon.setGravity(Gravity.CENTER);
        logo.addView(
                logoIcon,
                new LinearLayout.LayoutParams(dp(38), dp(38))
        );

        TextView logoName = new TextView(this);
        logoName.setText("Pijar Karier");
        logoName.setTextColor(WHITE);
        logoName.setTextSize(22);
        logoName.setTypeface(AppFont.semibold(this));

        LinearLayout.LayoutParams logoNameParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        logoNameParams.leftMargin = dp(10);
        logo.addView(logoName, logoNameParams);

        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        logoParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
        logoParams.bottomMargin = dp(18);
        root.addView(logo, logoParams);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(24), dp(22), dp(24));
        GradientDrawable cardBg = bulat(WHITE, 26);
        cardBg.setStroke(dp(1), Color.rgb(221, 224, 255));
        card.setBackground(cardBg);
        card.setElevation(dp(3));
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText("Lupa Password?");
        title.setTextColor(NAVY);
        title.setTextSize(30);
        title.setTypeface(AppFont.semibold(this));
        card.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(
                "Masukkan email yang terdaftar pada akun Pijar Karier. " +
                        "Kami akan mengirimkan tautan untuk membuat password baru."
        );
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(15);
        subtitle.setLineSpacing(dp(4), 1f);

        LinearLayout.LayoutParams subtitleParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        subtitleParams.topMargin = dp(10);
        subtitleParams.bottomMargin = dp(28);
        card.addView(subtitle, subtitleParams);

        TextView emailLabel = new TextView(this);
        emailLabel.setText("Email terdaftar");
        emailLabel.setTextColor(TEXT);
        emailLabel.setTextSize(14);
        emailLabel.setTypeface(AppFont.semibold(this));
        card.addView(emailLabel);

        etEmail = new EditText(this);
        etEmail.setSingleLine(true);
        etEmail.setHint("nama@email.com");
        etEmail.setTextColor(TEXT);
        etEmail.setHintTextColor(MUTED);
        etEmail.setTextSize(15);
        etEmail.setInputType(
                android.text.InputType.TYPE_CLASS_TEXT
                        | android.text.InputType
                        .TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        );
        etEmail.setPadding(dp(16), 0, dp(16), 0);
        etEmail.setBackground(inputBackground());

        LinearLayout.LayoutParams emailParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(56)
                );

        emailParams.topMargin = dp(10);
        emailParams.bottomMargin = dp(22);
        card.addView(etEmail, emailParams);

        btnReset = new Button(this);
        btnReset.setText("Kirim Tautan Reset");
        btnReset.setTextColor(WHITE);
        btnReset.setTextSize(15);
        btnReset.setTypeface(AppFont.semibold(this));
        btnReset.setAllCaps(false);
        btnReset.setBackground(bulat(TEAL, 14));
        btnReset.setElevation(dp(3));

        card.addView(
                btnReset,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(54)
                )
        );

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);

        LinearLayout.LayoutParams progressParams =
                new LinearLayout.LayoutParams(dp(30), dp(30));

        progressParams.gravity = Gravity.CENTER;
        progressParams.topMargin = dp(16);
        card.addView(progressBar, progressParams);

        TextView info = new TextView(this);
        info.setText(
                "Periksa kotak masuk dan folder spam setelah " +
                        "meminta tautan pemulihan."
        );
        info.setTextColor(MUTED);
        info.setTextSize(12);
        info.setGravity(Gravity.CENTER);
        info.setLineSpacing(dp(3), 1f);

        LinearLayout.LayoutParams infoParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        infoParams.topMargin = dp(18);
        card.addView(info, infoParams);

        btnReset.setOnClickListener(v -> prosesPemulihan());
        FontEnforcer.apply(scrollView, this);
        UiMotion.styleButtons(scrollView);
        UiMotion.bindActions(scrollView);
        UiMotion.bindPress(back);
        UiMotion.revealChildren(root, 60, 110, 4);
        UiMotion.revealChildren(card, 200, 55, 8);
    }

    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private void prosesPemulihan() {
        String email = etEmail.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email wajib diisi");
            etEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Format email tidak valid");
            etEmail.requestFocus();
            return;
        }

        sembunyikanKeyboard();
        setLoading(true);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                URL_FORGOT_PASSWORD,

                responseText -> {
                    setLoading(false);

                    try {
                        JSONObject response =
                                new JSONObject(responseText);

                        boolean success =
                                response.optBoolean("success", false);

                        String message = response.optString(
                                "message",
                                "Respons server tidak lengkap."
                        );

                        Toast.makeText(
                                ForgotPasswordActivity.this,
                                message,
                                Toast.LENGTH_LONG
                        ).show();

                        if (success) {
                            etEmail.setText("");
                        }

                    } catch (Exception e) {
                        Toast.makeText(
                                ForgotPasswordActivity.this,
                                "Respons server tidak valid.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },

                error -> {
                    setLoading(false);

                    String message =
                            "Tidak dapat terhubung ke server.";

                    if (error.networkResponse != null) {
                        int statusCode =
                                error.networkResponse.statusCode;

                        message += " (HTTP " + statusCode + ")";

                        if (statusCode == 404) {
                            message +=
                                    "\nPeriksa lokasi file PHP di hosting.";
                        } else if (statusCode == 405) {
                            message +=
                                    "\nServer menolak metode permintaan.";
                        } else if (statusCode >= 500) {
                            message +=
                                    "\nPeriksa konfigurasi PHP di server.";
                        }
                    }

                    Toast.makeText(
                            ForgotPasswordActivity.this,
                            message,
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                return params;
            }
        };

        request.setShouldCache(false);
        request.setRetryPolicy(
                new DefaultRetryPolicy(
                        20000,
                        0,
                        1.0f
                )
        );

        requestQueue.add(request);
    }

    private void setLoading(boolean loading) {
        btnReset.setEnabled(!loading);
        btnReset.setText(
                loading ? "Mengirim Permintaan..." : "Kirim Tautan Reset"
        );

        btnReset.setAlpha(loading ? 0.7f : 1f);

        etEmail.setEnabled(!loading);

        progressBar.setVisibility(
                loading ? View.VISIBLE : View.GONE
        );
    }

    private void sembunyikanKeyboard() {
        try {
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(
                            Context.INPUT_METHOD_SERVICE
                    );

            View currentFocus = getCurrentFocus();

            if (imm != null && currentFocus != null) {
                imm.hideSoftInputFromWindow(
                        currentFocus.getWindowToken(),
                        0
                );
            }
        } catch (Exception ignored) {
        }
    }

    private GradientDrawable bulat(int warna, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(warna);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private GradientDrawable inputBackground() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(WHITE);
        drawable.setCornerRadius(dp(14));
        drawable.setStroke(
                dp(1),
                Color.rgb(220, 228, 237)
        );
        return drawable;
    }

    private int dp(float value) {
        return (int) (
                value * getResources().getDisplayMetrics().density
                        + 0.5f
        );
    }
}
