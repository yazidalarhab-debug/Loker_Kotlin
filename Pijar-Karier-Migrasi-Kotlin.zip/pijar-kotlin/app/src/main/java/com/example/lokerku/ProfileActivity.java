package com.example.lokerku;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private static final String BASE = "https://ahannaja.cu.ma/lokerku_api/";
    private static final int NAVY = Color.rgb(21, 26, 61);
    private static final int BLUE = Color.rgb(0, 0, 255);
    private static final int MUTED = Color.rgb(104, 112, 143);
    private static final int BG = Color.rgb(247, 248, 255);

    private SharedPreferences pref;
    private RequestQueue queue;
    private ImageView imgFoto;
    private EditText etNama, etUsername, etEmail, etNoHp;
    private EditText etLokasi, etHeadline, etBio, etLinkedin, etPortfolio;
    private Button btnFoto, btnHapusFoto, btnSimpan, btnKeluar;
    private Uri fotoTerpilih;
    private ActivityResultLauncher<String> pilihFoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                            | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        pref = getSharedPreferences("lokerku_user", MODE_PRIVATE);
        queue = Volley.newRequestQueue(getApplicationContext());

        buatTampilan();
        isiProfil();
        etEmail.setEnabled(false); // Email changes require ownership verification.

        pilihFoto = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null) return;
            try {
                Bitmap bitmap = decodeBounded(uri, 1024);
                if (bitmap != null) { fotoTerpilih = uri; imgFoto.setImageBitmap(bitmap); }
                else Toast.makeText(this, "Foto tidak dapat dibuka", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Foto gagal dibuka", Toast.LENGTH_SHORT).show();
            }
        });

        btnFoto.setOnClickListener(v -> pilihFoto.launch("image/*"));
        btnHapusFoto.setOnClickListener(v -> new PremiumDialog.Builder(this)
                .setTitle("Hapus foto profil?").setMessage("Foto profil akan dihapus dari server.")
                .setNegativeButton("Batal", null).setPositiveButton("Hapus Foto", (dialog, which) -> {
                    ApiClient.post(this, "auth/delete_photo.php", new HashMap<>(), new ApiClient.Result() {
                        public void success(JSONObject json) { fotoTerpilih=null;pref.edit().remove("foto").apply();imgFoto.setImageResource(R.drawable.ic_lk_person);Toast.makeText(ProfileActivity.this,"Foto dihapus",Toast.LENGTH_SHORT).show(); }
                        public void fail(String message) { Toast.makeText(ProfileActivity.this,message,Toast.LENGTH_LONG).show(); }
                    });
                }).show());
        btnSimpan.setOnClickListener(v -> simpanProfil());
        btnKeluar.setOnClickListener(v -> new PremiumDialog.Builder(this)
                .setTitle("Keluar dari Pijar Karier?")
                .setMessage("Kamu perlu login kembali untuk membuka akun ini.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Keluar", (d, w) -> {
                    ApiClient.post(ProfileActivity.this, "auth/logout.php", new HashMap<>(), new ApiClient.Result() {
                        public void success(JSONObject ignored) { }
                        public void fail(String ignored) { }
                    });
                    SessionStore.clear(ProfileActivity.this);
                    pref.edit().clear().apply();
                    Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }).show());
    }

    private void buatTampilan() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(40));
        root.setClipChildren(false);
        root.setClipToPadding(false);
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        // Header gradient dengan sudut bawah membulat.
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(18), dp(20), dp(20));
        header.setBackground(organicHeaderBg(
                Color.rgb(22, 43, 115), Color.rgb(51, 79, 170)));
        if (android.os.Build.VERSION.SDK_INT >= 21) header.setElevation(dp(5));
        LinearLayout.LayoutParams headerParams = new LinearLayout.LayoutParams(-1, -2);
        headerParams.leftMargin = 0;
        headerParams.rightMargin = 0;
        root.addView(header, headerParams);

        TextView back = new TextView(this);
        back.setText("‹   Kembali");
        back.setTextSize(14);
        back.setTextColor(Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(15), dp(8), dp(18), dp(8));
        back.setBackground(roundBg(0x2AFFFFFF, dp(28)));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-2, dp(38));
        backParams.bottomMargin = dp(12);
        back.setMinHeight(dp(48));
        backParams.height = -2;
        header.addView(back, backParams);

        TextView title = new TextView(this);
        title.setText("Edit Profil");
        title.setTextSize(25);
        title.setTypeface(AppFont.semibold(this));
        title.setLetterSpacing(-0.015f);
        title.setTextColor(Color.WHITE);
        header.addView(title, wrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Kelola informasi akun dan data diri kamu di sini.");
        subtitle.setTextSize(14);
        subtitle.setLineSpacing(dp(3), 1.0f);
        subtitle.setTextColor(Color.rgb(224, 244, 249));
        LinearLayout.LayoutParams subtitleParams = wrap();
        subtitleParams.topMargin = dp(5);
        header.addView(subtitle, subtitleParams);

        // Kartu profil utama.
        LinearLayout hero = card(root);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(20), dp(18), dp(20));
        hero.setBackground(roundBg(Color.WHITE, dp(24)));
        if (android.os.Build.VERSION.SDK_INT >= 21) hero.setElevation(dp(2));
        LinearLayout.LayoutParams heroParams = (LinearLayout.LayoutParams) hero.getLayoutParams();
        heroParams.topMargin = dp(16);
        heroParams.leftMargin = dp(2);
        heroParams.rightMargin = dp(2);
        hero.setLayoutParams(heroParams);

        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.HORIZONTAL);
        identity.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(identity, wrap());

        imgFoto = new ImageView(this);
        imgFoto.setImageResource(R.drawable.ic_lk_person);
        imgFoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.GradientDrawable avatarBg = roundBg(Color.rgb(232, 232, 255), dp(60));
        avatarBg.setStroke(dp(3), Color.WHITE);
        imgFoto.setBackground(avatarBg);
        imgFoto.setClipToOutline(true);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(dp(68), dp(68));
        imageParams.rightMargin = dp(12);
        identity.addView(imgFoto, imageParams);

        LinearLayout identityText = new LinearLayout(this);
        identityText.setOrientation(LinearLayout.VERTICAL);
        identityText.setGravity(Gravity.CENTER_VERTICAL);
        identity.addView(identityText, new LinearLayout.LayoutParams(0, -2, 1));

        TextView namePreview = new TextView(this);
        String namaAwal = pref.getString("nama", "Pengguna Pijar Karier");
        namePreview.setText(namaAwal == null || namaAwal.trim().isEmpty() ? "Pengguna Pijar Karier" : namaAwal);
        namePreview.setTextSize(18);
        namePreview.setTypeface(AppFont.semibold(this));
        namePreview.setTextColor(NAVY);
        namePreview.setMaxLines(2);
        identityText.addView(namePreview, wrap());

        TextView usernamePreview = new TextView(this);
        usernamePreview.setText("@" + pref.getString("username", "username"));
        usernamePreview.setTextSize(13);
        usernamePreview.setTextColor(MUTED);
        usernamePreview.setMaxLines(2);

        LinearLayout.LayoutParams usernameParams = wrap();
        usernameParams.topMargin = dp(3);
        identityText.addView(usernamePreview, usernameParams);

        TextView emailPreview = new TextView(this);
        emailPreview.setText(pref.getString("email", "Email belum diisi"));
        emailPreview.setTextSize(12);
        emailPreview.setTextColor(MUTED);
        emailPreview.setMaxLines(3);

        LinearLayout.LayoutParams emailParams = wrap();
        emailParams.topMargin = dp(5);
        identityText.addView(emailPreview, emailParams);

        btnFoto = pillButton("Unggah / Ganti Foto", Color.rgb(0, 0, 255), Color.WHITE);
        LinearLayout.LayoutParams photoButtonParams = new LinearLayout.LayoutParams(-1, -2);
        photoButtonParams.topMargin = dp(16);
        hero.addView(btnFoto, photoButtonParams);

        btnHapusFoto = pillButton("Hapus Foto Profil", Color.rgb(239, 244, 255), Color.rgb(31, 55, 105));
        LinearLayout.LayoutParams removePhotoParams = new LinearLayout.LayoutParams(-1, -2);
        removePhotoParams.topMargin = dp(8);
        hero.addView(btnHapusFoto, removePhotoParams);

        tambahSection(root, "Informasi Pribadi", "Informasi utama akun kamu");
        LinearLayout basic = card(root);
        etNama = tambahInput(basic, "Nama lengkap", "Masukkan nama lengkap", false, false);
        etUsername = tambahInput(basic, "Username", "Nama pengguna", false, false);
        etEmail = tambahInput(basic, "Alamat email", "nama@email.com", false, false);
        etNoHp = tambahInput(basic, "Nomor HP", "Contoh: 081234567890", false, true);

        tambahSection(root, "Informasi Karier", "Lengkapi agar profilmu lebih menarik bagi perusahaan");
        LinearLayout career = card(root);
        etHeadline = tambahInput(career, "Headline profesional", "Bidang atau profesi", false, true);
        etLokasi = tambahInput(career, "Lokasi / domisili", "Kota tempat tinggal", false, true);
        etBio = tambahInput(career, "Tentang saya", "Ceritakan minat, keahlian, dan tujuan kariermu", true, true);
        etLinkedin = tambahInput(career, "LinkedIn", "https://linkedin.com/in/namamu", false, true);
        etPortfolio = tambahInput(career, "Portofolio / website", "https://website-kamu.com", false, true);

        TextView note = new TextView(this);
        note.setText("Info bertanda Opsional boleh dikosongkan. Simpan perubahan untuk memperbarui profil di Pijar Karier.");
        note.setTextColor(MUTED);
        note.setTextSize(12);
        note.setPadding(dp(5), dp(14), dp(5), dp(14));
        note.setLineSpacing(dp(3), 1.0f);
        root.addView(note, wrap());

        btnSimpan = pillButton("Simpan Perubahan", Color.rgb(0, 0, 255), Color.WHITE);
        btnSimpan.setTextSize(15);
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, -2);
        saveParams.topMargin = dp(4);
        root.addView(btnSimpan, saveParams);

        btnKeluar = pillButton("Keluar dari Akun", Color.rgb(255, 235, 238), Color.rgb(190, 47, 67));
        LinearLayout.LayoutParams logoutParams = new LinearLayout.LayoutParams(-1, -2);
        logoutParams.topMargin = dp(12);
        root.addView(btnKeluar, logoutParams);

        setContentView(scroll);
        FontEnforcer.apply(scroll, this);
        UiMotion.styleButtons(scroll);
        UiMotion.bindActions(scroll);
        UiMotion.bindPress(back);
        UiMotion.revealChildren(root, 40, 75, 10);
    }

    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private void tambahStat(LinearLayout parent, int icon, String title, String sub, int tint) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(5), dp(13), dp(5), dp(13));
        tile.setMinimumHeight(dp(132));
        if (android.os.Build.VERSION.SDK_INT >= 21) tile.setElevation(dp(3));
        tile.setBackground(roundBg(Color.WHITE, dp(22)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        p.setMargins(dp(4), 0, dp(4), 0);
        parent.addView(tile, p);

        ImageView symbol = new ImageView(this);
        symbol.setImageResource(icon);
        symbol.setColorFilter(Color.rgb(0, 0, 204));
        symbol.setPadding(dp(10), dp(10), dp(10), dp(10));
        symbol.setBackground(roundBg(tint, dp(30)));
        symbol.setContentDescription(null);
        tile.addView(symbol, new LinearLayout.LayoutParams(dp(42), dp(42)));

        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(NAVY);
        label.setTextSize(13);
        label.setTypeface(AppFont.semibold(this));
        label.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams labelP = wrap();
        labelP.topMargin = dp(7);
        tile.addView(label, labelP);

        TextView desc = new TextView(this);
        desc.setText(sub);
        desc.setTextColor(MUTED);
        desc.setTextSize(10);
        desc.setGravity(Gravity.CENTER);
        desc.setMaxLines(2);
        desc.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams descP = wrap();
        descP.topMargin = dp(2);
        tile.addView(desc, descP);
    }

    private void tambahSection(LinearLayout root, String title, String subtitle) {
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(NAVY);
        heading.setTextSize(19);
        heading.setTypeface(AppFont.semibold(this));
        LinearLayout.LayoutParams hp = wrap();
        hp.topMargin = dp(25);
        root.addView(heading, hp);

        TextView sub = new TextView(this);
        sub.setText(subtitle);
        sub.setTextColor(MUTED);
        sub.setTextSize(13);
        LinearLayout.LayoutParams sp = wrap();
        sp.topMargin = dp(4);
        sp.bottomMargin = dp(12);
        root.addView(sub, sp);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(12), dp(17), dp(22));
        if (android.os.Build.VERSION.SDK_INT >= 21) box.setElevation(dp(3));
        box.setBackground(roundBg(Color.WHITE, dp(24)));
        if (parent != null) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            parent.addView(box, p);
        }
        return box;
    }

    private EditText tambahInput(LinearLayout root, String label, String hint,
                                 boolean multiline, boolean optional) {
        LinearLayout labelRow = new LinearLayout(this);
        labelRow.setOrientation(LinearLayout.HORIZONTAL);
        labelRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.topMargin = dp(15);
        root.addView(labelRow, rowParams);

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(NAVY);
        tv.setTextSize(13);
        tv.setTypeface(AppFont.semibold(this));
        labelRow.addView(tv, new LinearLayout.LayoutParams(0, -2, 1));

        if (optional) {
            TextView badge = new TextView(this);
            badge.setText("(opsional)");
            badge.setTextColor(Color.rgb(87, 119, 151));
            badge.setTextSize(10);
            badge.setPadding(dp(5), dp(3), dp(5), dp(3));
            badge.setBackground(roundBg(Color.rgb(235, 242, 248), dp(20)));
            LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(-2, -2);
            badgeParams.leftMargin = dp(8);
            labelRow.addView(badge, badgeParams);
        }

        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setHintTextColor(Color.rgb(148, 164, 181));
        edit.setTextColor(NAVY);
        edit.setTextSize(14);
        edit.setPadding(dp(16), dp(12), dp(16), dp(12));
        android.graphics.drawable.GradientDrawable inputBg = roundBg(Color.rgb(247, 248, 255), dp(18));
        inputBg.setStroke(dp(1), Color.rgb(221, 224, 255));
        edit.setBackground(inputBg);
        edit.setSelectAllOnFocus(false);
        edit.setSingleLine(!multiline);
        if (label.toLowerCase(java.util.Locale.ROOT).contains("email")) {
            edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        } else if (label.toLowerCase(java.util.Locale.ROOT).contains("hp")) {
            edit.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        } else if (label.toLowerCase(java.util.Locale.ROOT).contains("linkedin")
                || label.toLowerCase(java.util.Locale.ROOT).contains("portofolio")) {
            edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        }
        if (multiline) {
            edit.setMinLines(3);
            edit.setMaxLines(6);
            edit.setGravity(Gravity.TOP | Gravity.START);
            edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        edit.setTypeface(AppFont.regular(this));
        edit.setMinHeight(multiline ? dp(132) : dp(56));
        LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(-1, -2);
        editParams.topMargin = dp(9);
        root.addView(edit, editParams);
        return edit;
    }

    private Button pillButton(String text, int backgroundColor, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(AppFont.semibold(this));
        button.setTextColor(textColor);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(20), 0, dp(20), 0);
        button.setLetterSpacing(0.01f);
        button.setIncludeFontPadding(false);
        button.setMinHeight(dp(48));
        android.graphics.drawable.GradientDrawable buttonBg = roundBg(backgroundColor, dp(16));
        buttonBg.setStroke(dp(1), backgroundColor == Color.rgb(255, 235, 238)
                ? Color.rgb(255, 207, 214) : backgroundColor);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            android.graphics.drawable.RippleDrawable ripple = new android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(0x22FFFFFF), buttonBg, null);
            button.setBackground(ripple);
            button.setElevation(dp(2));
        } else {
            button.setBackground(buttonBg);
        }
        button.setStateListAnimator(null);
        return button;
    }

    private android.graphics.drawable.GradientDrawable organicHeaderBg(int start, int end) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{start, 0xff253f91, end});
        // Bagian atas lembut, sudut bawah lebih lebar agar header tidak tampak kotak.
        d.setCornerRadii(new float[]{
                dp(30), dp(30), dp(30), dp(30),
                dp(26), dp(26), dp(26), dp(26)
        });
        return d;
    }


    private void isiProfil() {
        etNama.setText(pref.getString("nama", ""));
        etUsername.setText(pref.getString("username", ""));
        etEmail.setText(pref.getString("email", ""));
        etNoHp.setText(pref.getString("phone", pref.getString("no_hp", "")));
        etHeadline.setText(pref.getString("profile_headline", ""));
        etLokasi.setText(pref.getString("profile_lokasi", ""));
        etBio.setText(pref.getString("profile_bio", ""));
        etLinkedin.setText(pref.getString("profile_linkedin", ""));
        etPortfolio.setText(pref.getString("profile_portfolio", ""));

        String foto = pref.getString("foto", "");
        if (foto != null && (foto.startsWith("https://") || foto.startsWith("http://"))) {
            com.android.volley.toolbox.ImageRequest imageRequest =
                    new com.android.volley.toolbox.ImageRequest(foto,
                            bitmap -> imgFoto.setImageBitmap(bitmap), dp(300), dp(300),
                            ImageView.ScaleType.CENTER_CROP, Bitmap.Config.RGB_565,
                            error -> { });
            queue.add(imageRequest);
        }
    }

    private void simpanProfil() {
        String id = String.valueOf(pref.getInt("id", 0));
        String nama = etNama.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String noHp = etNoHp.getText().toString().trim();
        String headline=etHeadline.getText().toString().trim(), lokasi=etLokasi.getText().toString().trim();
        String bio=etBio.getText().toString().trim(), linkedin=etLinkedin.getText().toString().trim(), portfolio=etPortfolio.getText().toString().trim();

        if (nama.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Nama dan email wajib diisi", Toast.LENGTH_SHORT).show();
            return;
        }
        if (id.equals("0")) {
            Toast.makeText(this, "ID akun tidak ditemukan. Silakan login kembali.", Toast.LENGTH_LONG).show();
            return;
        }

        btnSimpan.setEnabled(false);
        StringRequest request = new StringRequest(Request.Method.POST, BASE + "auth/update_profile.php",
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.optBoolean("success")) {
                            pref.edit()
                                    .putString("nama", nama)
                                    .putString("username", username)
                                    .putString("email", email)
                                    .putString("phone", noHp)
                                    .putString("profile_headline", headline)
                                    .putString("profile_lokasi", lokasi)
                                    .putString("profile_bio", bio)
                                    .putString("profile_linkedin", linkedin)
                                    .putString("profile_portfolio", portfolio)
                                    .apply();
                            if (fotoTerpilih != null) uploadFoto(id);
                            else {
                                btnSimpan.setEnabled(true);
                                Toast.makeText(this, "Profil berhasil diperbarui", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        } else {
                            btnSimpan.setEnabled(true);
                            Toast.makeText(this, json.optString("message", "Profil gagal diperbarui"), Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        btnSimpan.setEnabled(true);
                        Toast.makeText(this, "Respons profil dari server tidak valid", Toast.LENGTH_LONG).show();
                    }
                }, error -> {
            btnSimpan.setEnabled(true);
            Toast.makeText(this, errorMessage(error, "menyimpan profil"), Toast.LENGTH_LONG).show();
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("id", id);
                p.put("session_token", SessionStore.get(ProfileActivity.this));
                p.put("nama", nama);
                p.put("username", username);
                p.put("email", email);
                p.put("no_hp", noHp);
                p.put("profile_headline", headline);
                p.put("profile_lokasi", lokasi);
                p.put("profile_bio", bio);
                p.put("profile_linkedin", linkedin);
                p.put("profile_portfolio", portfolio);
                return p;
            }
        };
        request.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(20000, 0, 1f));
        request.setShouldCache(false);
        queue.add(request);
    }

    private String errorMessage(com.android.volley.VolleyError error, String task) {
        if (error.networkResponse != null) {
            int status = error.networkResponse.statusCode;
            try {
                JSONObject body = new JSONObject(new String(error.networkResponse.data, java.nio.charset.StandardCharsets.UTF_8));
                String message = body.optString("message", "").trim();
                if (!message.isEmpty() && status < 500) return message + " (HTTP " + status + ")";
            } catch (Exception ignored) { }
            return "Server gagal saat " + task + " (HTTP " + status + ").";
        }
        return "Tidak dapat terhubung saat " + task + ". Periksa internet dan coba lagi.";
    }

    private Bitmap decodeBounded(Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Foto tidak tersedia");
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new Exception("Foto tidak valid");
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / options.inSampleSize > maxSide * 2)
            options.inSampleSize *= 2;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Foto tidak tersedia");
            return BitmapFactory.decodeStream(in, null, options);
        }
    }

    private void uploadFoto(String id) {
        try {
            Bitmap bitmap = decodeBounded(fotoTerpilih, 1024);
            if (bitmap == null) throw new Exception("Foto tidak valid");

            int max = 1024;
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            float scale = Math.min(1f, Math.min(max / (float) width, max / (float) height));
            Bitmap resized = Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(width * scale)),
                    Math.max(1, Math.round(height * scale)), true);
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            resized.compress(Bitmap.CompressFormat.JPEG, 82, output);
            byte[] bytes = output.toByteArray();

            VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,
                    BASE + "auth/upload_photo.php", response -> {
                btnSimpan.setEnabled(true);
                try {
                    JSONObject json = new JSONObject(new String(response.data, "UTF-8"));
                    if (json.optBoolean("success")) {
                        String url = json.optString("foto", "");
                        pref.edit().putString("foto", url).apply();
                        Toast.makeText(this, "Profil dan foto berhasil disimpan", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Profil tersimpan; " + json.optString("message", "foto gagal diunggah"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Profil tersimpan, tetapi respons unggah foto tidak valid.", Toast.LENGTH_LONG).show();
                }
            }, error -> {btnSimpan.setEnabled(true); Toast.makeText(this, "Profil tersimpan. " + errorMessage(error, "mengunggah foto"), Toast.LENGTH_LONG).show();}) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("id", id);
                    params.put("session_token", SessionStore.get(ProfileActivity.this));
                    return params;
                }
                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> files = new HashMap<>();
                    files.put("foto", new DataPart("profil.jpg", bytes, "image/jpeg"));
                    return files;
                }
            };
            request.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(30000, 0, 1f));
            request.setShouldCache(false);
            queue.add(request);
        } catch (Exception e) {
            btnSimpan.setEnabled(true);
            Toast.makeText(this, "Profil tersimpan, tetapi foto gagal diproses.", Toast.LENGTH_LONG).show();
        }
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        if (color == Color.WHITE) d.setStroke(dp(1), Color.rgb(221, 224, 255));
        d.setCornerRadius(radius);
        return d;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    public abstract static class VolleyMultipartRequest extends Request<NetworkResponse> {
        private final Response.Listener<NetworkResponse> listener;
        private final Response.ErrorListener errorListener;
        private final String boundary = "LokerKuBoundary" + System.currentTimeMillis();

        public VolleyMultipartRequest(int method, String url,
                                      Response.Listener<NetworkResponse> listener,
                                      Response.ErrorListener errorListener) {
            super(method, url, errorListener);
            this.listener = listener;
            this.errorListener = errorListener;
        }

        protected abstract Map<String, DataPart> getByteData();

        public static class DataPart {
            public String fileName;
            public byte[] content;
            public String type;
            public DataPart(String fileName, byte[] content, String type) {
                this.fileName = fileName;
                this.content = content;
                this.type = type;
            }
        }

        @Override
        public String getBodyContentType() {
            return "multipart/form-data; boundary=" + boundary;
        }

        @Override
        public byte[] getBody() throws AuthFailureError {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                String line = "\r\n";
                String twoHyphens = "--";
                for (Map.Entry<String, String> entry : getParams().entrySet()) {
                    out.write((twoHyphens + boundary + line
                            + "Content-Disposition: form-data; name=\"" + entry.getKey() + "\"" + line + line
                            + entry.getValue() + line).getBytes("UTF-8"));
                }
                for (Map.Entry<String, DataPart> entry : getByteData().entrySet()) {
                    DataPart data = entry.getValue();
                    out.write((twoHyphens + boundary + line
                            + "Content-Disposition: form-data; name=\"" + entry.getKey()
                            + "\"; filename=\"" + data.fileName + "\"" + line
                            + "Content-Type: " + data.type + line + line).getBytes("UTF-8"));
                    out.write(data.content);
                    out.write(line.getBytes("UTF-8"));
                }
                out.write((twoHyphens + boundary + twoHyphens + line).getBytes("UTF-8"));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Gagal menyiapkan upload foto" : e.getMessage();
                throw new AuthFailureError(message);
            }
            return out.toByteArray();
        }

        @Override
        protected Response<NetworkResponse> parseNetworkResponse(NetworkResponse response) {
            return Response.success(response, com.android.volley.toolbox.HttpHeaderParser.parseCacheHeaders(response));
        }

        @Override
        protected void deliverResponse(NetworkResponse response) {
            listener.onResponse(response);
        }
    }
}
