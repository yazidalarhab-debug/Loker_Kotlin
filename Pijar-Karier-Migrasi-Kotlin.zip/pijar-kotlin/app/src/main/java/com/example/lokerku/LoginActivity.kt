package com.example.lokerku

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {
    private lateinit var identity: EditText
    private lateinit var password: EditText
    private lateinit var login: Button
    private lateinit var progress: ProgressBar
    private lateinit var queue: RequestQueue
    private fun dp(n: Int) = (n * resources.displayMetrics.density + .5f).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1,-2)
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        typeface = if (bold) AppFont.semibold(this@LoginActivity) else AppFont.regular(this@LoginActivity)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = PijarStyle.CREAM; window.navigationBarColor = PijarStyle.PURPLE_DARK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        queue = Volley.newRequestQueue(applicationContext)
        buildLoginScreen()
    }
    private fun buildLoginScreen() {
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(PijarStyle.CREAM) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24),dp(22),dp(24),dp(30)) }
        scroll.addView(root)
        root.addView(label("‹  Kembali",14f,PijarStyle.PURPLE,true).apply {
            minHeight = dp(48); gravity = Gravity.CENTER_VERTICAL; setOnClickListener { finish() }
        },matchWrap())
        root.addView(label("✦  PIJAR KARIER",12f,PijarStyle.PURPLE,true).apply { letterSpacing = .08f },
            matchWrap().apply { setMargins(0,dp(16),0,dp(14)) })
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22),dp(20),dp(22),dp(20))
            background = PijarStyle.gradient(this@LoginActivity,PijarStyle.PURPLE_DARK,0xff7851c0.toInt(),24f)
        }
        hero.addView(label("LANGKAHMU SELANJUTNYA  ✦",10f,0xffd9f5e8.toInt(),true).apply { letterSpacing = .06f })
        hero.addView(label("Senang melihatmu\nkembali!",24f,Color.WHITE,true),matchWrap().apply { topMargin = dp(8) })
        root.addView(hero,matchWrap().apply { bottomMargin = dp(24) })
        root.addView(label("Masuk ke akun",21f,PijarStyle.INK,true),matchWrap())
        root.addView(label("Lanjutkan perjalanan kariermu.",13f,PijarStyle.MUTED),matchWrap().apply { setMargins(0,dp(4),0,dp(22)) })
        root.addView(label("Email atau username",14f,PijarStyle.INK,true),matchWrap())
        identity = input("Masukkan email atau username",false); root.addView(identity,matchWrap())
        root.addView(label("Password",14f,PijarStyle.INK,true),matchWrap().apply { topMargin = dp(16) })
        password = input("Masukkan password",true); root.addView(password,matchWrap())
        root.addView(label("Lupa password?",13f,PijarStyle.PURPLE,true).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL; minHeight = dp(48)
            setOnClickListener { startActivity(Intent(this@LoginActivity,ForgotPasswordActivity::class.java)) }
        },matchWrap())
        login = Button(this).apply {
            text = "Masuk"; setTextColor(Color.WHITE); textSize = 15f; isAllCaps = false
            typeface = AppFont.semibold(this@LoginActivity); backgroundTintList = null; stateListAnimator = null
            background = PijarStyle.surface(this@LoginActivity,PijarStyle.PURPLE,16f); minHeight = dp(54)
            setOnClickListener { loginUser() }
        }
        root.addView(login,matchWrap())
        root.addView(label("ATAU LANJUTKAN DENGAN",10f,PijarStyle.MUTED).apply {
            letterSpacing = .08f; gravity = Gravity.CENTER; setPadding(0,dp(18),0,0)
        },matchWrap())
        GoogleDesign.addTo(root,this,"Masuk dengan Google")
        progress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        root.addView(progress,LinearLayout.LayoutParams(dp(36),dp(36)).apply { gravity = Gravity.CENTER; topMargin = dp(12) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        root.addView(row,matchWrap().apply { topMargin = dp(14) })
        row.addView(label("Belum punya akun? ",13f,PijarStyle.MUTED))
        row.addView(label("Daftar",13f,PijarStyle.PURPLE,true).apply {
            setPadding(dp(8),dp(14),dp(8),dp(14)); setOnClickListener { startActivity(Intent(this@LoginActivity,RegisterActivity::class.java)) }
        })
        setContentView(scroll); FontEnforcer.apply(root,this); UiMotion.styleButtons(root); UiMotion.bindActions(root); UiMotion.reveal(hero,50)
    }
    private fun input(hintText: String, isPassword: Boolean): EditText = EditText(this).apply {
        setSingleLine(true); setTextColor(PijarStyle.INK); setHintTextColor(0xff777188.toInt()); textSize = 14f; hint = hintText
        setPadding(dp(15),dp(12),dp(15),dp(12)); val bg = PijarStyle.surface(this@LoginActivity,Color.WHITE,14f)
        bg.setStroke(dp(1),0xffdfd8ea.toInt()); backgroundTintList = null; background = bg
        setOnFocusChangeListener { field, focused ->
            bg.setStroke(dp(if (focused) 2 else 1),if (focused) PijarStyle.PURPLE else 0xffdfd8ea.toInt())
            ObjectAnimator.ofFloat(field,View.TRANSLATION_Z,if (focused) dp(3).toFloat() else 0f).apply { duration = 220; start() }
        }
        minHeight = dp(52)
        inputType = InputType.TYPE_CLASS_TEXT or if (isPassword) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        typeface = AppFont.regular(this@LoginActivity)
    }
    private fun loginUser() {
        val name = identity.text.toString().trim(); val secret = password.text.toString()
        if (name.isEmpty()) { identity.error = "Email atau username wajib diisi"; identity.requestFocus(); return }
        if (secret.isEmpty()) { password.error = "Password wajib diisi"; password.requestFocus(); return }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.let { manager ->
            currentFocus?.windowToken?.let { manager.hideSoftInputFromWindow(it,0) }
        }
        setLoading(true)
        val request = object : StringRequest(Request.Method.POST,"https://ahannaja.cu.ma/lokerku_api/auth/login.php",responseListener@{ response ->
            setLoading(false)
            try {
                val json = JSONObject(response)
                if (!json.optBoolean("success",false)) { showMessage(json.optString("message","Login gagal")); return@responseListener }
                val user = json.optJSONObject("user") ?: json.optJSONObject("data")
                if (user == null) { showMessage("Data pengguna tidak ditemukan"); return@responseListener }
                if (user.optInt("id",0) <= 0) { showMessage("ID pengguna tidak valid"); return@responseListener }
                val username = if (user.isNull("username")) "" else user.optString("username", "")
                GoogleSignInFlow.saveUser(this,user,json.optString("session_token", ""))
                Toast.makeText(this,"Login berhasil",Toast.LENGTH_SHORT).show()
                startActivity(Intent(this,MainActivity::class.java).putExtra("username",username)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            } catch (e: Exception) { showMessage("Respons server tidak valid") }
        }, { error ->
            setLoading(false); var message = "Tidak dapat terhubung ke server"
            val data = error.networkResponse?.data
            if (data != null) try { message = JSONObject(String(data,Charsets.UTF_8)).optString("message",message) } catch (_: Exception) { }
            showMessage(message)
        }) {
            override fun getParams(): MutableMap<String,String> = hashMapOf("username" to name,"password" to secret)
        }
        request.setShouldCache(false); request.retryPolicy = DefaultRetryPolicy(15000,1,1f); queue.add(request)
    }
    private fun setLoading(loading: Boolean) { login.isEnabled = !loading; login.text = if (loading) "Memproses..." else "Masuk"; progress.visibility = if (loading) View.VISIBLE else View.GONE }
    private fun showMessage(message: String) { Toast.makeText(this,message,Toast.LENGTH_LONG).show() }
    override fun onPause() { UiMotion.finishReveals(window.decorView); super.onPause() }
}
