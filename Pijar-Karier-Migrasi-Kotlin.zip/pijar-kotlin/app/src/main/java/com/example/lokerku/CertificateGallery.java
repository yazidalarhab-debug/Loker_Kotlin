package com.example.lokerku;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Public certificate thumbnails shown on the user's own profile. */
final class CertificateGallery {
    private static final ExecutorService PDF_WORKER = Executors.newFixedThreadPool(2);
    private final Activity activity;
    private final LinearLayout panel;
    private final RequestQueue queue;
    private int dp(float n) { return (int)(n*activity.getResources().getDisplayMetrics().density+.5f); }
    private CertificateGallery(Activity activity, LinearLayout panel) {
        this.activity=activity; this.panel=panel; queue=Volley.newRequestQueue(activity.getApplicationContext());
    }
    static void show(Activity a, LinearLayout panel) { new CertificateGallery(a,panel).load(); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t=new TextView(activity);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setTypeface(bold?AppFont.semibold(activity):AppFont.regular(activity));return t;
    }
    private GradientDrawable bg(int color, int radius) {GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private void load() {
        panel.removeAllViews(); TextView status=text("Memuat galeri…",12,0xff68708f,false);status.setPadding(dp(14),dp(16),dp(14),dp(16)); panel.addView(status);
        HashMap<String,String> params=new HashMap<>();params.put("action","list");
        ApiClient.post(activity,"profile/certificates.php",params,new ApiClient.Result(){
            public void success(JSONObject json){
                if(!panel.isAttachedToWindow())return;panel.removeAllViews();JSONArray items=json.optJSONArray("certificates");
                if(items==null||items.length()==0){empty();return;}
                LinearLayout row=null;int count=0;
                for(int i=0;i<items.length();i++){
                    JSONObject item=items.optJSONObject(i);if(item==null||item.optLong("id",0)<=0)continue;
                    if(count%3==0){row=new LinearLayout(activity);row.setOrientation(LinearLayout.HORIZONTAL);panel.addView(row);}
                    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(tile(item),p);count++;
                }
                if(count==0){empty();return;}
                int rem=count%3; if(rem>0)for(int i=rem;i<3;i++){View filler=new View(activity);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,1,1);p.setMargins(dp(2),0,dp(2),0);row.addView(filler,p);}
                UiMotion.revealChildren(panel,30,55,3);
            }
            public void fail(String message){if(!panel.isAttachedToWindow())return;panel.removeAllViews();TextView err=text("Galeri belum dapat dimuat. Ketuk untuk mencoba lagi.",12,0xff6b728b,false);err.setPadding(dp(12),dp(16),dp(12),dp(16));err.setOnClickListener(v->load());panel.addView(err);}
        });
    }
    private void empty(){TextView empty=text("Belum ada sertifikat. Ketuk + Tambah untuk menampilkan pencapaianmu di sini.",12,0xff68708f,false);empty.setLineSpacing(dp(3),1f);empty.setPadding(dp(16),dp(24),dp(16),dp(24));empty.setGravity(Gravity.CENTER);empty.setBackground(bg(0xfff1f4ff,16));panel.addView(empty);}
    private View tile(JSONObject item){
        long id=item.optLong("id");String label=item.optString("label","Sertifikat");boolean pdf="application/pdf".equals(item.optString("file_type"));
        Square tile=new Square(activity);tile.setBackground(bg(0xffe9edff,12));tile.setClipToOutline(true);
        ImageView image=new ImageView(activity);image.setScaleType(pdf?ImageView.ScaleType.FIT_CENTER:ImageView.ScaleType.CENTER_CROP);tile.addView(image,new FrameLayout.LayoutParams(-1,-1));
        TextView fallback=text(pdf?"PDF":"✦",pdf?14:24,0xff4353c8,true);fallback.setGravity(Gravity.CENTER);tile.addView(fallback,new FrameLayout.LayoutParams(-1,-1));
        TextView name=text((pdf?"PDF  ·  ":"")+label,10,Color.WHITE,true);name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(dp(7),dp(13),dp(7),dp(6));
        GradientDrawable shade=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00131b48,0xd91a2145});name.setBackground(shade);
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);tile.addView(name,np);
        tile.setContentDescription("Lihat sertifikat: "+label);tile.setOnClickListener(v->preview(item,image.getDrawable()));UiMotion.bindPress(tile);
        String url=ApiClient.BASE+"profile/certificate_file.php?id="+id;
        if(pdf)loadPdf(url,image,fallback);else {
            ImageRequest request=new ImageRequest(url,bitmap->{image.setImageBitmap(bitmap);fallback.setVisibility(View.GONE);},450,450,ImageView.ScaleType.CENTER_CROP,Bitmap.Config.RGB_565,error->{fallback.setText("Gambar");});
            request.setShouldCache(false);queue.add(request);
        }
        return tile;
    }
    private void preview(JSONObject item, android.graphics.drawable.Drawable drawable){
        String label=item.optString("label","Sertifikat");long id=item.optLong("id");
        LinearLayout body=new LinearLayout(activity);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),dp(8),dp(18),dp(4));
        ImageView image=new ImageView(activity);image.setBackground(bg(0xfff2f4ff,16));image.setScaleType(ImageView.ScaleType.FIT_CENTER);if(drawable!=null)image.setImageDrawable(drawable);else image.setImageResource(R.drawable.ic_lk_info_outline);
        body.addView(image,new LinearLayout.LayoutParams(-1,dp(250)));
        TextView detail=text("Sertifikat ini bersifat publik.",12,0xff68708f,false);detail.setPadding(0,dp(10),0,0);body.addView(detail);
        new PremiumDialog.Builder(activity).setTitle(label).setView(body).setNegativeButton("Tutup",null).setPositiveButton("Buka dokumen",(d,w)->{
            try{activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(ApiClient.BASE+"profile/certificate_file.php?id="+id)));}catch(Exception e){Toast.makeText(activity,"Tidak ada aplikasi untuk membuka dokumen.",Toast.LENGTH_LONG).show();}
        }).show();
    }
    private void loadPdf(String url,ImageView image,TextView fallback){
        PDF_WORKER.execute(()->{Bitmap bitmap=null;File tmp=null;HttpURLConnection conn=null;
            try{
                conn=(HttpURLConnection)new URL(url).openConnection();conn.setConnectTimeout(12000);conn.setReadTimeout(12000);conn.setInstanceFollowRedirects(false);
                if(conn.getResponseCode()!=200)throw new Exception("http");
                tmp=File.createTempFile("cert_preview_",".pdf",activity.getCacheDir());
                try(InputStream in=conn.getInputStream();FileOutputStream out=new FileOutputStream(tmp)){byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>5*1024*1024)throw new Exception("large");out.write(b,0,n);}}
                try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(tmp,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)){
                    if(renderer.getPageCount()<1)throw new Exception("empty");
                    try(PdfRenderer.Page page=renderer.openPage(0)){int w=360;int h=Math.max(1,Math.min(600,(int)((long)w*page.getHeight()/Math.max(1,page.getWidth()))));bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);new Canvas(bitmap).drawColor(Color.WHITE);page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);}
                }
            }catch(Exception ignored){}finally{if(conn!=null)conn.disconnect();if(tmp!=null)tmp.delete();}
            final Bitmap result=bitmap;activity.runOnUiThread(()->{if(result!=null&&!activity.isFinishing()&&image.isAttachedToWindow()){image.setImageBitmap(result);fallback.setVisibility(View.GONE);}});
        });
    }
    private static final class Square extends FrameLayout {Square(Activity a){super(a);}@Override protected void onMeasure(int w,int h){super.onMeasure(w,View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(w),View.MeasureSpec.EXACTLY));}}
}
