# Pijar Karier — migrasi Kotlin sebagian

Ini adalah migrasi bertahap, **belum sepenuhnya Kotlin**. Splash, layar sambutan, layar login, palet Pijar, tombol Google dan alur integrasi Google telah ditulis dalam Kotlin. Dashboard, registrasi, profil, fitur lowongan dan komponen lain masih Java; keduanya tetap berada dalam satu proyek Android.

## Android Studio dan JDK

- Di Settings > Build, Execution, Deployment > Build Tools > Gradle, pilih Gradle JDK **17** (seperti versi 17.0.21 pada gambar). Tidak ada path khusus komputer yang ditanamkan.
- Proyek memakai Gradle wrapper 7.6.4, Kotlin plugin 1.9.0, Android Gradle Plugin 7.1.2 dan SDK 34. Android Studio akan membuat `local.properties` untuk lokasi SDK Anda.
- AGP 7.1.2 mengeluarkan peringatan bahwa compileSdk 34 lebih baru dari versi yang diuji oleh plugin ini; konfigurasi dipertahankan untuk membatasi perubahan proyek.

## Login Google dan API

Integrasi mempertahankan Web Client ID dan alamat API yang ada pada ZIP asli. Aplikasi meminta nonce dari `auth/google_nonce.php`, lalu mengirim token, nonce dan mode login/registrasi ke `auth/google.php`. Tidak ada server PHP atau kredensial server baru yang ditambahkan. Tombol login dan daftar Google memakai alur yang sama seperti proyek awal.

Login Google riil belum diuji. Perangkat membutuhkan Google Play services, backend yang siap dan konfigurasi OAuth yang sesuai, termasuk SHA-1 dari sertifikat aplikasi yang digunakan. APK debug menggunakan sertifikat debug pembuatnya, sehingga SHA-1-nya mungkin belum terdaftar. Registrasi Google dan login Google mengikuti kebijakan backend lama; akun Google harus didaftarkan terlebih dahulu jika backend mensyaratkannya.

Aplikasi tetap menggunakan applicationId `com.example.lokerku`. Pemasangan di perangkat yang sudah memiliki aplikasi lama bisa ditolak jika tanda tangan berbeda, atau memperbarui aplikasi lama jika tanda tangan sama. Jangan menghapus aplikasi lama sebelum memastikan data yang diperlukan sudah dicadangkan.

## Verifikasi

Build debug dan tes unit contoh berhasil menggunakan JDK 17.0.21. Uji secara manual layar login, pembuatan akun dan Google, respons API, error jaringan, serta tampilan pada beberapa ukuran layar. Tes contoh bawaan hanya menguji penjumlahan, bukan fitur aplikasi. Tidak ada jaminan bahwa seluruh aplikasi sudah termigrasi atau semua alur server berjalan tanpa pengujian perangkat dan backend.
